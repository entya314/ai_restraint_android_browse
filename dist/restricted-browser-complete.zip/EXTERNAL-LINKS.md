# 外部リンク受信の追加仕様（0.2.0、0.3.0更新）

SPEC.mdは初回依頼原文として保持します。本書は追加依頼「他のアプリからブラウザとして認識・起動できるようにする」の実装仕様です。

- Androidの通常のHTTP/HTTPSリンク（ACTION_VIEW）を受け取り、標準ブラウザ候補に登録する。URLなしでブラウザを起動するAPP_BROWSERセレクターにも対応する。
- URLは直接入力・QRと同じポリシーで検証する。HTTP、検索エンジン、不正URL、別schemeは表示しない。検索語の起動や外部fallbackを追加しない。
- 初回起動・開始画面では検証済みURLを新規セッションとして開き、0.3.0では最初のHTTP転送を解決した最終host・HTTPS・実効portを固定する（詳細はINITIAL-REDIRECTS.md）。
- **利用者が選択した動作：閲覧中は確認画面を出し、了承した場合だけ現在の閲覧を終了して新しいリンクを開く。** キャンセル・戻る操作では現在の閲覧を維持する。同じhostでも確認する。
- 了承時は既存のCookie・ストレージ・履歴の消去を行う。Cookie消去完了前に次のページを開かない。送信済み注文を取り消す操作ではない。
- 起動済みActivityに集約し、タブや並行セッションを作らない。古い確認結果や破棄後のコールバックで新しいページを勝手に開かない。
- 標準ブラウザの選択はAndroid設定で行う。アプリ内の設定画面・メニューは追加しない。
- Custom Tabsサービス、ACTION_SEND、端末全体の制限は今回の対象外。

実装：MainActivity、ExternalLinkCoordinator、AndroidManifest.xml。
検証：TEST-REPORT.md、verification/。
